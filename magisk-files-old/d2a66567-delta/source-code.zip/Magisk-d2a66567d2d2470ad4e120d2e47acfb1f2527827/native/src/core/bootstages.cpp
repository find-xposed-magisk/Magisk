#include <sys/mount.h>
#include <sys/wait.h>
#include <sys/sysmacros.h>
#include <linux/input.h>
#include <libgen.h>
#include <set>
#include <string>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <sys/vfs.h>

#include <magisk.hpp>
#include <db.hpp>
#include <base.hpp>
#include <daemon.hpp>
#include <selinux.hpp>

#include "core.hpp"
#include "zygisk/zygisk.hpp"

#define COUNT_FAILBOOT "/cache/.magisk_checkboot"

#define VLOGD(tag, from, to) LOGD("%-8s: %s <- %s\n", tag, to, from)

using namespace std;

#define FIX_MIRRORS 1

#define TST_RAMFS_MAGIC    0x858458f6
#define TST_TMPFS_MAGIC    0x01021994
#define TST_OVERLAYFS_MAGIC 0x794c7630

bool is_rootfs()
{
    const char *path= "/";
    struct statfs s;
    statfs(path, &s);
    
    switch (s.f_type) {
    case TST_TMPFS_MAGIC:
    case TST_RAMFS_MAGIC:
    case TST_OVERLAYFS_MAGIC:
        return true;
    default:
        return false;
    }
}

int ztrigger_count = 0;
static bool bootloop_protect = false;


static const char *preinit_part[]={
        PREINIT_PARTS,
        "/mnt/vendor/persist",
        nullptr
    };


static bool is_persist_access(const char *file){
    for (int i=0;preinit_part[i];i++) {
        string sfile = string(preinit_part[i]) + "/" + file;
        if (access(sfile.data(), F_OK) == 0) {
            LOGD("daemon: found trigger file [%s]\n", sfile.data());
            return true;
        }
    }
    return false;
}

static void create_persist_file(const char *file){
    for (int i=0;preinit_part[i];i++) {
        string sfile = string(preinit_part[i]) + "/" + file;
        LOGD("daemon: create trigger file [%s]\n", sfile.data());
        close(xopen(sfile.data(), O_RDONLY | O_CREAT, 0));
    }
}

static void remove_persist_access(const char *file){
    for (int i=0;preinit_part[i];i++) {
        string sfile = string(preinit_part[i]) + "/" + file;
        if (access(sfile.data(), F_OK) == 0) {
            LOGD("daemon: remove trigger file [%s]\n", sfile.data());
            rm_rf(sfile.data());
        }
    }
}

void reboot_coreonly(){
    create_persist_file(".disable_all");
    LOGI("** Reboot to recovery");
    exec_command_sync("/system/bin/reboot", "recovery");
}

bool check_bootloop(const char *name, const char *filename, int max)
{
    int n=1;
    if (access(filename, F_OK) != 0) {
        // not exist, we need create file with initial value
        FILE *ztrigger=fopen(filename, "wb");
        if (ztrigger == NULL) return false; // failed
        fwrite(&n,1,sizeof(int),ztrigger);
        fclose(ztrigger);
    }
    FILE *ztrigger=fopen(filename, "rb");
    if (ztrigger == NULL) return false; // failed
    fread(&n, 1, sizeof(int), ztrigger);
    fclose(ztrigger);
    // current number here
        if (n >= max) {
            LOGI("anti_bootloop: %s reachs %d times, restart!\n", name, max);
            reboot_coreonly();
        } else LOGI("%s count = %d\n", name, n);
    
    ztrigger=fopen(filename, "wb");
    if (ztrigger == NULL) return false; // failed
    n++; // increase the number
    fwrite(&n, 1, sizeof(int), ztrigger);
    fclose(ztrigger);
    return true;
}


// Boot stage state
enum : int {
    FLAG_NONE = 0,
    FLAG_POST_FS_DATA_DONE = (1 << 0),
    FLAG_LATE_START_DONE = (1 << 1),
    FLAG_BOOT_COMPLETE = (1 << 2),
    FLAG_SAFE_MODE = (1 << 3),
};

static int boot_state = FLAG_NONE;

bool zygisk_enabled = false;
bool sulist_enabled = false;

static const char *F2FS_SYSFS_PATH = nullptr;

/*********
 * Setup *
 *********/
 
 
void recreate_sbin_v2(const char *mirror, bool use_bind_mount) {
    auto dp = xopen_dir(mirror);
    int src = dirfd(dp.get());
    char buf[4096];
    char mbuf[4096];
    for (dirent *entry; (entry = xreaddir(dp.get()));) {
        string sbin_path = "/sbin/"s + entry->d_name;
        struct stat st;
        fstatat(src, entry->d_name, &st, AT_SYMLINK_NOFOLLOW);
        sprintf(buf, "%s/%s", mirror, entry->d_name);
        sprintf(mbuf, "%s/%s", MAGISKTMP.data(), entry->d_name);
        if (access(mbuf, F_OK) == 0) continue;
        if (S_ISLNK(st.st_mode)) {
            xreadlinkat(src, entry->d_name, buf, sizeof(buf));
            xsymlink(buf, sbin_path.data());
            VLOGD("create", buf, sbin_path.data());
        } else {
            if (use_bind_mount) {
                auto mode = st.st_mode & 0777;
                // Create dummy
                if (S_ISDIR(st.st_mode))
                    xmkdir(sbin_path.data(), mode);
                else
                    close(xopen(sbin_path.data(), O_CREAT | O_WRONLY | O_CLOEXEC, mode));

                bind_mount_(buf, sbin_path.data());
            } else {
                xsymlink(buf, sbin_path.data());
                VLOGD("create", buf, sbin_path.data());
            }
        }
    }
}
static bool mount_mirror(const std::string_view from, const std::string_view to) {
    return !mount(from.data(), to.data(), nullptr, MS_BIND, nullptr) &&
           // make mirror dir as a private mount so that it won't be affected by magic mount
           !xmount(nullptr, to.data(), nullptr, MS_PRIVATE, nullptr);
}

void mount_mirrors() {
    std::vector<mount_info> self_mount_info;
    mount_info rootfs_info;

    auto root_mirror_dir = MAGISKTMP + "/" ROOTMIRR;
    mkdir(root_mirror_dir.data(), 0);
    xmount("tmpfs", root_mirror_dir.data(), "tmpfs", 0, nullptr);

    // Workaround "Too many dev.mnt.blk properties crash system_server" on Infinix devices
    // By making source (devblock) does not start with /dev/block/
    // https://github.com/topjohnwu/Magisk/issues/6927
    do {
        // collect mountinfo and filter mount that are blocked by other mount
        auto current_mount_info = parse_mount_info("self");
        std::map<std::string_view, std::set<dev_t>> device_blocks;

        for (auto &info : reversed(current_mount_info)){
            if (info.target == "/") {
                rootfs_info = info;
            }
            for (auto &s : self_mount_info) {
                // skip if mount that are blocked by other mount
                if (s.target == info.target || info.target.starts_with(s.target + "/"))
                    goto next_mountpoint;
            }
            self_mount_info.emplace_back(info);
            // create directory for mirror
            xmkdirs((MAGISKTMP + "/" MIRRDIR + info.target).data(), 0);
            // collect ext4 and f2fs device block
            if (info.type == "ext4" || info.type == "f2fs" || info.type == "erofs") {
                device_blocks[info.type].insert(info.device);
            }
            next_mountpoint:
            continue;
        }

        // mount all device block to MAGISKTMP/.magisk/root
        auto block_dir = MAGISKTMP + "/" BLOCKDIR;
        chdir(block_dir.data());
        for (auto &[fs_type, blocks] : device_blocks) {
            mkdir(string(fs_type).data(), 0);
            for (auto &info : blocks) {
                string root_block = string(fs_type) + "/" + std::to_string(info);
                string root_mirror = MAGISKTMP + "/" ROOTMIRR "/" + string(fs_type) + "/" + std::to_string(info);
                xmkdirs(root_mirror.data(), 0);
                unlink(root_block.data());
                mknod(root_block.data(), S_IFBLK, info);
                if (xmount(root_block.data(), root_mirror.data(), string(fs_type).data(), MS_RDONLY, nullptr) == 0 ||
                    xmount(root_block.data(), root_mirror.data(), string(fs_type).data(), 0, nullptr) == 0) {
                    xmount(nullptr, root_mirror.data(), nullptr, MS_REMOUNT | MS_BIND | MS_RDONLY, nullptr);
                    xmount(nullptr, root_mirror.data(), nullptr, MS_PRIVATE, nullptr);
                    LOGD("%-8s: %s (%s)\n", "setup", root_mirror.data(), string(fs_type).data());
                } else {
                    rmdir(root_mirror.data());
                }
            }
        }

        chdir("/");
        std::reverse(self_mount_info.begin(), self_mount_info.end());
    } while(false);

    // Check and mount preinit mirror
    if (struct stat st{}; stat((MAGISKTMP + "/" PREINITDEV).data(), &st) == 0 && (st.st_mode & S_IFBLK)) {
        // DO NOT mount the block device directly, as we do not know the flags and configs
        // to properly mount the partition; mounting block devices directly as rw could cause
        // crashes if the filesystem driver is crap (e.g. some broken F2FS drivers).
        // What we do instead is to scan through the current mountinfo and find a pre-existing
        // mount point mounting our desired partition, and then bind mount the target folder.
        dev_t preinit_dev = st.st_rdev;
        bool mounted = false;
        for (const auto &info: self_mount_info) {
            if (info.root == "/" && info.device == preinit_dev) {
                auto flags = split_view(info.fs_option, ",");
                auto rw = std::any_of(flags.begin(), flags.end(), [](const auto &flag) {
                    return flag == "rw"sv;
                });
                if (!rw) continue;
                string preinit_dir = resolve_preinit_dir(info.target.data());
                string early_mnt_dir = resolve_early_mount_dir(info.target.data());
                //
                xmkdir(preinit_dir.data(), 0700);
                xmkdir(early_mnt_dir.data(), 0700);
                xmkdir((early_mnt_dir + "/initrc.d").data(), 0700);
                //
                auto mirror_dir = MAGISKTMP + "/" PREINITMIRR;
                if ((mounted = mount_mirror(preinit_dir, mirror_dir))) {
                    xmount(nullptr, mirror_dir.data(), nullptr, MS_UNBINDABLE, nullptr);
                    xmount(early_mnt_dir.data(), (MAGISKTMP + "/" EARLYMNTRO).data(), nullptr, MS_BIND, nullptr);
                    break;
                }
            }
        }
        if (!mounted) {
            LOGW("preinit mirror not mounted %u:%u\n", major(preinit_dev), minor(preinit_dev));
            unlink((MAGISKTMP + "/" PREINITDEV).data());
        }
    }

    // Prepare worker
    auto worker_dir = MAGISKTMP + "/" WORKERDIR;
    xmount("worker", worker_dir.data(), "tmpfs", 0, "mode=755");
    xmount(nullptr, worker_dir.data(), nullptr, MS_PRIVATE, nullptr);

    if (auto mirror_dir = MAGISKTMP + "/" MIRRDIR; true) {
        chdir(root_mirror_dir.data());
        { // mounting system root
            auto src = rootfs_info.type + "/" + std::to_string(rootfs_info.device) + ((rootfs_info.root == "/")? "" : rootfs_info.root);;
            if (mount(src.data(), mirror_dir.data(), nullptr, MS_BIND, nullptr) == 0) {
                 LOGD("%-8s: %s <- %s\n", "mirror", mirror_dir.data(), src.data());
            } else if (mount_mirror("/", mirror_dir)) {
                 LOGD("%-8s: %s <- /\n", "mirror", mirror_dir.data());
            }
        }
        // Recursively bind mount to mirror dir
        for (const auto &info: self_mount_info) {
            if (info.target == "/"sv) continue;
            auto src = info.type + "/" + std::to_string(info.device) + ((info.root == "/")? "" : info.root);
            auto dest = mirror_dir + info.target;
            if (mount(src.data(), dest.data(), nullptr, MS_BIND, nullptr) == 0) {
                 LOGD("%-8s: %s <- %s\n", "mirror", dest.data(), src.data());
            } else if (mount_mirror(info.target, mirror_dir + info.target)) {
                 LOGD("%-8s: %s <- %s\n", "mirror", dest.data(), info.target.data());
            }
        }
        chdir("/");
    }

    // Bind remount module root to clear nosuid
    if (access(SECURE_DIR, F_OK) == 0 || SDK_INT < 24) {
        auto src = MAGISKTMP + "/" MIRRDIR MODULEROOT;
        auto dest = MAGISKTMP + "/" MODULEMNT;
        xmkdir(SECURE_DIR, 0700);
        xmkdir(MODULEROOT, 0755);
        xmkdir(dest.data(), 0755);
        xmount(src.data(), dest.data(), nullptr, MS_BIND, nullptr);
        chmod(SECURE_DIR, 0700);
    }
}

string find_preinit_device() {
    enum part_t {
        UNKNOWN,
        PERSIST,
        METADATA,
        CACHE,
        DATA,
    };

    part_t ext4_type = UNKNOWN;
    part_t f2fs_type = UNKNOWN;

    bool encrypted = get_prop("ro.crypto.state") == "encrypted";
    bool mount = getuid() == 0 && getenv("MAGISKTMP");
    bool make_dev = mount && getenv("MAKEDEV");

    string preinit_source;
    string preinit_dir;
    dev_t preinit_dev;

    for (const auto &info: parse_mount_info("self")) {
        if (info.target.ends_with(PREINITMIRR))
            return basename(info.source.data());
        if (info.root != "/" || info.source[0] != '/' || info.source.find("/dm-") != string::npos)
            continue;
        // Skip all non ext4 partitions once we found a matching ext4 partition
        if (ext4_type != UNKNOWN && info.type != "ext4")
            continue;
        if (info.type != "ext4" && info.type != "f2fs")
            continue;
        auto flags = split_view(info.fs_option, ",");
        auto rw = std::any_of(flags.begin(), flags.end(), [](const auto &flag) {
            return flag == "rw"sv;
        });
        if (!rw) continue;
        if (auto base = std::string_view(info.source).substr(0, info.source.find_last_of('/'));
            !base.ends_with("/by-name") && !base.ends_with("/block")) {
            continue;
        }

        part_t &matched = (info.type == "f2fs") ? f2fs_type : ext4_type;
        switch (matched) {
            case UNKNOWN:
                if (info.target == "/persist" || info.target == "/mnt/vendor/persist") {
                    matched = PERSIST;
                    break;
                }
                [[fallthrough]];
            case PERSIST:
                if (info.target == "/metadata") {
                    matched = METADATA;
                    break;
                }
                [[fallthrough]];
            case METADATA:
                if (info.target == "/cache") {
                    matched = CACHE;
                    break;
                }
                [[fallthrough]];
            case CACHE:
                if (info.target == "/data") {
                    if (!encrypted || access("/data/unencrypted", F_OK) == 0) {
                        matched = DATA;
                        break;
                    }
                }
                [[fallthrough]];
            default:
                continue;
        }

        if (mount) {
            preinit_dir = resolve_preinit_dir(info.target.data());
            preinit_dev = info.device;
        }
        preinit_source = info.source;

        // Cannot find any better partition, stop finding
        if (ext4_type == DATA)
            break;
    }

    if (preinit_source.empty())
        return "";

    if (!preinit_dir.empty()) {
        auto mirror_dir = string(getenv("MAGISKTMP")) + "/" PREINITMIRR;
        mkdirs(preinit_dir.data(), 0700);
        mkdirs(mirror_dir.data(), 0700);
        xmount(preinit_dir.data(), mirror_dir.data(), nullptr, MS_BIND, nullptr);
        if (make_dev) {
            auto dev_path = string(getenv("MAGISKTMP")) + "/" PREINITDEV;
            xmknod(dev_path.data(), S_IFBLK | 0600, preinit_dev);
        }
    }
    return basename(preinit_source.data());
}

static bool magisk_env() {
    char buf[4096];

    LOGI("* Initializing Magisk environment\n");

    preserve_stub_apk();
    string pkg;
    get_manager(0, &pkg);

    ssprintf(buf, sizeof(buf), "%s/0/%s/install", APP_DATA_DIR,
            pkg.empty() ? "xxx" /* Ensure non-exist path */ : pkg.data());

    // Alternative binaries paths
    const char *alt_bin[] = { "/cache/data_adb/magisk", "/data/magisk", buf };
    struct stat st{};
    for (auto alt : alt_bin) {
        if (lstat(alt, &st) == 0) {
            if (S_ISLNK(st.st_mode)) {
                unlink(alt);
                continue;
            }
            rm_rf(DATABIN);
            cp_afc(alt, DATABIN);
            rm_rf(alt);
            break;
        }
    }
    rm_rf("/cache/data_adb");

    // Directories in /data/adb
    if (!is_dir_exist(MODULEROOT)) rm_rf(MODULEROOT);
    xmkdir(DATABIN, 0755);
    xmkdir(SECURE_DIR "/post-fs-data.d", 0755);
    xmkdir(SECURE_DIR "/service.d", 0755);
    restorecon();

    if (access(DATABIN "/busybox", X_OK))
        return false;

    sprintf(buf, "%s/" BBPATH "/busybox", MAGISKTMP.data());
    mkdir(dirname(buf), 0755);
    cp_afc(DATABIN "/busybox", buf);
    exec_command_async(buf, "--install", "-s", dirname(buf));

    if (access(DATABIN "/magiskpolicy", X_OK) == 0) {
        sprintf(buf, "%s/magiskpolicy", MAGISKTMP.data());
        cp_afc(DATABIN "/magiskpolicy", buf);
    }

    return true;
}

void reboot() {
    if (RECOVERY_MODE)
        exec_command_sync("/system/bin/reboot", "recovery");
    else
        exec_command_sync("/system/bin/reboot");
}

static bool core_only(bool rm_trigger = false){
    if (is_persist_access(".disable_magisk")){
        if (rm_trigger){
            remove_persist_access(".disable_magisk");
        }
        return true;
    }
    return false;
}


static bool should_skip_all(){
    if (is_persist_access(".disable_all")){
        remove_persist_access(".disable_all");
        rm_rf(COUNT_FAILBOOT);
        return true;
    }
    return false;
}
    

static bool check_data() {
    bool mnt = false;
    file_readline("/proc/mounts", [&](string_view s) {
        if (str_contains(s, " /data ") && !str_contains(s, "tmpfs")) {
            mnt = true;
            return false;
        }
        return true;
    });
    if (!mnt)
        return false;
    auto crypto = get_prop("ro.crypto.state");
    if (!crypto.empty()) {
        if (crypto != "encrypted") {
            // Unencrypted, we can directly access data
            return true;
        } else {
            // Encrypted, check whether vold is started
            return !get_prop("init.svc.vold").empty();
        }
    }
    // ro.crypto.state is not set, assume it's unencrypted
    return true;
}

static bool system_lnk(const char *path){
    char buff[4098];
    ssize_t len = readlink(path, buff, sizeof(buff)-1);
    if (len != -1) {
        return true;
    }
    return false;
}

static void simple_mount(const string &sdir, const string &ddir = "") {
    auto dir = xopen_dir(sdir.data());
    if (!dir) return;
    for (dirent *entry; (entry = xreaddir(dir.get()));) {
        string src = sdir + "/" + entry->d_name;
        string dest = ddir + "/" + entry->d_name;
        if (access(dest.data(), F_OK) == 0 && !system_lnk(dest.data())) {
            if (entry->d_type == DT_LNK) continue;
            else if (entry->d_type == DT_DIR) {
                // Recursive
                simple_mount(src, dest);
            } else {
                LOGD("bind_mnt: %s <- %s\n", dest.data(), src.data());
                xmount(src.data(), dest.data(), nullptr, MS_BIND, nullptr);
            }
        }
    }
}

void unlock_blocks() {
    int fd, dev, OFF = 0;

    auto dir = xopen_dir("/dev/block");
    if (!dir)
        return;
    dev = dirfd(dir.get());

    for (dirent *entry; (entry = readdir(dir.get()));) {
        if (entry->d_type == DT_BLK) {
            if ((fd = openat(dev, entry->d_name, O_RDONLY | O_CLOEXEC)) < 0)
                continue;
            if (ioctl(fd, BLKROSET, &OFF) < 0)
                PLOGE("unlock %s", entry->d_name);
            close(fd);
        }
    }
}


int mount_sbin(){
    if (is_rootfs()){
        if (xmount(nullptr, "/", nullptr, MS_REMOUNT, nullptr) != 0) return -1;
        mkdir("/sbin", 0750);
        rm_rf("/root");
        mkdir("/root", 0750);
        clone_attr("/sbin", "/root");
        link_path("/sbin", "/root");
        if (tmpfs_mount("magisk", "/sbin") != 0) return -1;
        setfilecon("/sbin", "u:object_r:rootfs:s0");
        recreate_sbin_v2("/root", false);
        xmount(nullptr, "/", nullptr, MS_REMOUNT | MS_RDONLY, nullptr);
    } else {
        if (tmpfs_mount("magisk", "/sbin") != 0) return -1;
        setfilecon("/sbin", "u:object_r:rootfs:s0");
        xmkdir("/sbin/" INTLROOT, 0755);
        xmkdir("/sbin/" MIRRDIR, 0755);
        xmkdir("/sbin/" MIRRDIR "/system_root", 0755);
        xmount("/", "/sbin/" MIRRDIR "/system_root", nullptr, MS_BIND, nullptr);
        recreate_sbin_v2("/sbin/" MIRRDIR "/system_root/sbin", true);
        umount2("/sbin/" MIRRDIR "/system_root", MNT_DETACH);
    }
    return 0;
}

#define test_bit(bit, array) (array[bit / 8] & (1 << (bit % 8)))

static bool check_key_combo() {
    uint8_t bitmask[(KEY_MAX + 1) / 8];
    vector<int> events;
    constexpr char name[] = "/dev/.ev";

    // First collect candidate events that accepts volume down
    for (int minor = 64; minor < 96; ++minor) {
        if (xmknod(name, S_IFCHR | 0444, makedev(13, minor)))
            continue;
        int fd = open(name, O_RDONLY | O_CLOEXEC);
        unlink(name);
        if (fd < 0)
            continue;
        memset(bitmask, 0, sizeof(bitmask));
        ioctl(fd, EVIOCGBIT(EV_KEY, sizeof(bitmask)), bitmask);
        if (test_bit(KEY_VOLUMEDOWN, bitmask))
            events.push_back(fd);
        else
            close(fd);
    }
    if (events.empty())
        return false;

    run_finally fin([&]{ std::for_each(events.begin(), events.end(), close); });

    // Check if volume down key is held continuously for more than 3 seconds
    for (int i = 0; i < 300; ++i) {
        bool pressed = false;
        for (const int &fd : events) {
            memset(bitmask, 0, sizeof(bitmask));
            ioctl(fd, EVIOCGKEY(sizeof(bitmask)), bitmask);
            if (test_bit(KEY_VOLUMEDOWN, bitmask)) {
                pressed = true;
                break;
            }
        }
        if (!pressed)
            return false;
        // Check every 10ms
        usleep(10000);
    }
    LOGD("KEY_VOLUMEDOWN detected: enter safe mode\n");
    return true;
}

#define F2FS_DEF_CP_INTERVAL "60"
#define F2FS_TUNE_CP_INTERVAL "200"
#define F2FS_DEF_GC_THREAD_URGENT_SLEEP_TIME "500"
#define F2FS_TUNE_GC_THREAD_URGENT_SLEEP_TIME "50"
#define BLOCK_SYSFS_PATH "/sys/block"
#define TUNE_DISCARD_MAX_BYTES "134217728"

static inline bool tune_f2fs_target(const char *device) {
    // Tune only SCSI (UFS), eMMC, NVMe and virtual devices
    return !strncmp(device, "sd", 2) ||
           !strncmp(device, "mmcblk", 6) ||
           !strncmp(device, "nvme", 4) ||
           !strncmp(device, "vd", 2) ||
           !strncmp(device, "xvd", 3);
}

static void __tune_f2fs(const char *dir, const char *device, const char *node,
                        const char *def, const char *val, bool wr_only) {
    char path[128], buf[32];
    int flags = F_OK | R_OK | W_OK;

    sprintf(path, "%s/%s/%s", dir, device, node);
    chmod(path, 0644);

    if (wr_only)
        flags &= ~R_OK;
    if (access(path, flags) != 0)
        return;

    int fd = xopen(path, wr_only ? O_WRONLY : O_RDWR);
    if (fd < 0)
        return;

    if (!wr_only) {
        ssize_t len;
        len = xread(fd, buf, sizeof(buf));
        if (buf[len - 1] == '\n')
            buf[len - 1] = '\0';
        if (strncmp(buf, def, len)) {
            // Something else changed this node from the kernel's default.
            // Pass.
            LOGD("tune_f2fs: skip node %s\n", node);
            close(fd);
            return;
        }
    }

    xwrite(fd, val, strlen(val));
    close(fd);

    LOGD("tune_f2fs: %s -> %s\n", path, val);
}

static void tune_f2fs() {
    // Check f2fs sys path
    if (access("/sys/fs/f2fs", F_OK) == 0)
        F2FS_SYSFS_PATH = "/sys/fs/f2fs";
    else if (access("/sys/fs/f2fs_dev", F_OK) == 0)
        F2FS_SYSFS_PATH = "/sys/fs/f2fs_dev";
    else {
        LOGD("tune_f2fs: /sys/fs/f2fs is not found, skip tuning!\n");
        return;
    }
    LOGI("tune_f2fs: %s\n", F2FS_SYSFS_PATH);
    // Tune f2fs sysfs node
    if (auto dir = xopen_dir(F2FS_SYSFS_PATH); dir) {
        for (dirent *entry; (entry = readdir(dir.get()));) {
            if (entry->d_name == "."sv || entry->d_name == ".."sv || !tune_f2fs_target(entry->d_name))
                continue;

            __tune_f2fs(F2FS_SYSFS_PATH, entry->d_name, "cp_interval",
                F2FS_DEF_CP_INTERVAL, F2FS_TUNE_CP_INTERVAL, false);
            __tune_f2fs(F2FS_SYSFS_PATH, entry->d_name, "gc_urgent_sleep_time",
                F2FS_DEF_GC_THREAD_URGENT_SLEEP_TIME, F2FS_TUNE_GC_THREAD_URGENT_SLEEP_TIME, false);
        }
    }

    // Tune block discard limit
    if (auto dir = xopen_dir(BLOCK_SYSFS_PATH); dir) {
        for (dirent *entry; (entry = readdir(dir.get()));) {
            if (entry->d_name == "."sv || entry->d_name == ".."sv || !tune_f2fs_target(entry->d_name))
                continue;

            __tune_f2fs(BLOCK_SYSFS_PATH, entry->d_name, "queue/discard_max_bytes",
                nullptr, TUNE_DISCARD_MAX_BYTES, true);
        }
    }
}


/***********************
 * Boot Stage Handlers *
 ***********************/

extern int disable_deny();

static void post_fs_data() {
    if (!check_data())
        return;

    rust::get_magiskd().setup_logfile();

    LOGI("** post-fs-data mode running\n");

    db_settings dbs;
    get_db_settings(dbs, ANTI_BOOTLOOP);
    bool coreonly_mode = core_only(false);
    bootloop_protect = dbs[ANTI_BOOTLOOP];

    LOGI("* Unlock device blocks\n");
    unlock_blocks();
    LOGI("* Mounting mirrors\n");
    mount_mirrors();
    prune_su_access();

    LOGI("PATH=[%s]\n", getenv("PATH"));

    if (access(SECURE_DIR, F_OK) != 0) {
        LOGE(SECURE_DIR " is not present, abort\n");
        goto early_abort;
    }

    if (!magisk_env()) {
        LOGE("* Magisk environment incomplete, abort\n");
        goto early_abort;
    }

    if (get_prop("persist.sys.safemode", true) == "1" ||
        get_prop("ro.sys.safemode") == "1" || check_key_combo() || should_skip_all()) {
        boot_state |= FLAG_SAFE_MODE;
        LOGI("** Safe mode triggered\n");
        // Disable all modules and denylist so next boot will be clean
        disable_modules();
        disable_deny();
        prepare_modules();
    } else {
        get_db_settings(dbs, ZYGISK_CONFIG);
        get_db_settings(dbs, WHITELIST_CONFIG);
        get_db_settings(dbs, DENYLIST_CONFIG);

        if(coreonly_mode){
            LOGI("** Core-only mode, ignore modules\n");
            // Core-only mode only disable modules
            boot_state |= FLAG_SAFE_MODE;
            disable_modules();
            // we still allow zygisk
            zygisk_enabled = dbs[ZYGISK_CONFIG];
            sulist_enabled = dbs[DENYLIST_CONFIG] && dbs[WHITELIST_CONFIG];
            initialize_denylist();
            prepare_modules();
            goto early_abort;
        }
        if (bootloop_protect) {
            if (!check_bootloop("boot_record", COUNT_FAILBOOT,3))
                LOGE("cannot record boot\n");
        }
        exec_common_scripts("post-fs-data");

        zygisk_enabled = dbs[ZYGISK_CONFIG];
        sulist_enabled = dbs[DENYLIST_CONFIG] && dbs[WHITELIST_CONFIG];
        initialize_denylist();
        handle_modules();
    }

early_abort:
    // We still do magic mount because root itself might need it
    load_modules();
    boot_state |= FLAG_POST_FS_DATA_DONE;
}

static void late_start() {
    rust::get_magiskd().setup_logfile();

    LOGI("** late_start service mode running\n");

    exec_common_scripts("service");
    exec_module_scripts("service");

    boot_state |= FLAG_LATE_START_DONE;
}

static void boot_complete() {
    boot_state |= FLAG_BOOT_COMPLETE;
    rust::get_magiskd().setup_logfile();

    LOGI("** boot-complete triggered\n");
    rm_rf(COUNT_FAILBOOT);
    tune_f2fs();

    
    if (zygisk_enabled && get_prop(NATIVE_BRIDGE_PROP) != orig_native_bridge) {
        LOGE("zygisk: unable to inject through native bridge\n");
        set_prop(NATIVE_BRIDGE_PROP, orig_native_bridge.data(), false);
        zygisk_enabled = false;
    }

    // At this point it's safe to create the folder
    if (access(SECURE_DIR, F_OK) != 0)
        xmkdir(SECURE_DIR, 0700);

    // Ensure manager exists
    check_pkg_refresh();
    get_manager(0, nullptr, true);
}

void boot_stage_handler(int client, int code) {
    // Make sure boot stage execution is always serialized
    static pthread_mutex_t stage_lock = PTHREAD_MUTEX_INITIALIZER;
    mutex_guard lock(stage_lock);

    switch (code) {
    case MainRequest::POST_FS_DATA:
        if ((boot_state & FLAG_POST_FS_DATA_DONE) == 0)
            post_fs_data();
        close(client);
        break;
    case MainRequest::LATE_START:
        close(client);
        if ((boot_state & FLAG_POST_FS_DATA_DONE) && (boot_state & FLAG_SAFE_MODE) == 0)
            late_start();
        break;
    case MainRequest::BOOT_COMPLETE:
        close(client);
        if ((boot_state & FLAG_SAFE_MODE) == 0)
            boot_complete();
        break;
    default:
        __builtin_unreachable();
    }
}

void perform_check_bootloop() {
    db_settings dbs;
    get_db_settings(dbs, ANTI_BOOTLOOP);
    if (((boot_state & FLAG_BOOT_COMPLETE) == 0 && bootloop_protect)){
        ztrigger_count++;
        if (ztrigger_count >= 8){
            reboot_coreonly();
        }
    }
}
